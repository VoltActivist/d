# Importo modulet
from colorama import Fore

# Logo
logo = """
===========================                              ==================
===========================
===========================----------ANONYMOUS ALBANIA---==================
===========================
===========================---------ANONYMOUS SUDAN------===================

About Script:
Code By Albania and Sudan 
 12,10,2023
"""
CRED2 = '\33[91m'
print(CRED2 + logo + CRED2) 
